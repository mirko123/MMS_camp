#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "list.h"

int main(void) {
	char *str = "test string";
	queue q;
	datum d;
	list *lp;
	int j, key;
	void *l;
	
	srand(0xa738c92fu);
	
	init_queue(&q);
	
	for (j = 0; j < 32; j++) {
		if (rand() & 1) {
			d.type = CHARP;
			d.d.cp = strdup(str);
		} else {
			d.type = INT;
			d.d.i = rand();
		}
		addE(&q, j, d);
	}
	
	l = search(&q, 0, &d);
	if (l) {
		for (j = 32; j < 64; j++) {
			if (rand() & 1) {
				d.type = CHARP;
				d.d.cp = strdup(str);
			} else {
				d.type = INT;
				d.d.i = rand();
			}
			if (!(l = addL(&q, l, j, d))) break;
		}
	}
	l = search(&q, 31, &d);
	if (l) {
		for (j = 64; j < 80; j++) {
			if (rand() & 1) {
				d.type = CHARP;
				d.d.cp = strdup(str);
			} else {
				d.type = INT;
				d.d.i = rand();
			}
			if (!(l = addR(&q, l, j, d))) break;
		}
	}
	
	for (j = 0; j < 100; j++)
		if (search(&q, j, &d)) {
			printf("found key %d data ", j);
			switch (d.type) {
			case INT:
				printf("%d\n", d.d.i);
				break;
			case CHARP:
				printf("%s\n", d.d.cp);
				break;
			default:
				printf("unknown\n");
			}
		}
	
	for (lp = q.B; lp; lp = lp->next) {
		printf("key %d data ", lp->key);
		switch (lp->d.type) {
		case INT:
			printf("%d\n", lp->d.d.i);
			break;
		case CHARP:
			printf("%s\n", lp->d.d.cp);
			free(lp->d.d.cp);
			break;
		default:
			printf("unknown\n");
		}
	}
	
	del_queue(&q);
	
	return 0;
}

