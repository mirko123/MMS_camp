#ifndef _P1_H_
#define _P1_H_

void clear(unsigned int *, int);
int get(const unsigned int *, int, int);
int set(unsigned int *, int, int, int);

#endif
