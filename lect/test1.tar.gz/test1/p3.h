#ifndef _P3_H_
#define _P3_H_

int getpix(const unsigned char *, int, int, int, int);
int setpix(unsigned char *, int, int, int, int, int);
void display(const unsigned char *, int, int);

#endif
