#ifndef _P2_H_
#define _P2_H_

void clear(unsigned char *, int);
int get(const unsigned char *, int, int);
int set(unsigned char *, int, int, int);

#endif
