#ifndef _P2_H_
#define _P2_H_

void clear( unsigned char*, int N);
int get(const unsigned char*, int N, int bit);
int set( unsigned char*, int N, int bit, int boolean);


#endif
