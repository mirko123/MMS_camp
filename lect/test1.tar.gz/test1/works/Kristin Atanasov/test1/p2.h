#ifndef _P1_H_
#define _P1_H_H

void clearCH(unsigned char *, int N);
int getCH(const unsigned char *, int N, int bit);
int setCH(unsigned char *, int N, int bit, int boolean);


#endif
