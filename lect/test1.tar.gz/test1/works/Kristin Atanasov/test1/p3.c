#include <stdlib.h>
#include "p3.h"


int getpix(const unsigned char *ch, int M, int N, int X, int Y){
	
	

}
int setpix(const unsigned char *ch, int M, int N, int X, int Y, int colour){
	
	

}
void display(const unsigned char *ch, int M, int N){
	
	int i ,j;
	
	for( i = 0; i <	M; i++){
		
		for (j = 0; j < N; j++){

		}
	}

	return;
}

