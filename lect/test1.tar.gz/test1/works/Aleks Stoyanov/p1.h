#ifndef _P1_H_
#define _P1_H_

void clear(unsigned int *t, int N);
int get(const unsigned int *t, int N, int bit);
int set(unsigned int *t, int N, int bit, int boolean);
void printb(unsigned int a);

#endif
