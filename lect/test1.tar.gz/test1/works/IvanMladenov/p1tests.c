#include <stdio.h>
#include <string.h>

#include "p1.h"

int main (void) {

	bin_arr b;
	
	
	
return 0;
}
