#ifndef _P1_H_
#define _P1_H_

void clear(unsigned int *i, int N);

int get(const unsigned int *i, int N, int bit);
int set(unsigned int *i, int N, int bit, int boolean);

#endif


