

void clear(unsigned int *px, int N);
int get(const unsigned int *px, int N, int bit); /* -1 -> range error */
int set(unsigned int *px, int N, int bit, int boolean); /* -1 -> range error */
