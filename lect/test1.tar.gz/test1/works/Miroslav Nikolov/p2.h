#ifndef _p2_
#define _p2_

void clear(unsigned char *arr, int N);
int get(const unsigned char *arr, int N, int bits);
int set(unsigned char *arr, int N, int bits, int boolean);


#endif
