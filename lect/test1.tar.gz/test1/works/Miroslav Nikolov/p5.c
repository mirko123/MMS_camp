#ifndef _p5_
#define _p5_

void readFile(void);


#endif
