#ifndef _p3_
#define _p3_

int getpix(const unsigned char* arr, int M, int N, int X, int Y);
int setpix(unsigned char* arr, int M, int N, int X, int Y, int colour);
void display(const unsigned char* arr, int M, int N);


#endif
