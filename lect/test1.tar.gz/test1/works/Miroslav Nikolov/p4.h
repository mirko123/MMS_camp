#ifndef _p4_
#define _p4_

void test(void);


#endif
