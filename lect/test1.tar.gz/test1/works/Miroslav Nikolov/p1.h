#ifndef _p1_
#define _p1_

void clear(unsigned int *arr, int N);
int get(const unsigned int *arr, int N, int bits);
int set(unsigned int *arr, int N, int bits, int boolean);


#endif
