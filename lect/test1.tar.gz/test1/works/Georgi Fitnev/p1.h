#ifndef _P1_H_
#define _P1_H_


/*struct list
{
int data;
struct list *next;
}
typedef list list;

struct boolarr
{

}
typedef struct boolarr boolarr;
*/

void clear(unsigned int * , int N);
int get(const unsigned int *, int N, int bit);
int set(unsigned int *, int N , int bit, int boolean);




#endif
