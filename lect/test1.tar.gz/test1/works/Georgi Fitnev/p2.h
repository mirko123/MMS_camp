#ifndef _P1_H_
#define _P1_H_


/*struct list
{
int data;
struct list *next;
}
typedef list list;

struct boolarr
{

}
typedef struct boolarr boolarr;
*/

void clear(unsigned char * , int N);
int get(const unsigned char *, int N, int bit);
int set(unsigned char *, int N , int bit, int boolean);




#endif
