#include<stdio.h>
#include<stdlib.h>
#include "p3.h"

int main(void){

	return 0;
}

int getpix(const unsigned char *, int M, int N, int X, int Y){
	if((i < 0 || i >= M)) return -1;
	if((j < 0 || j >= N)) return -1;
	 
}
int setpix(unsigned char *, int M, int N, int X, int Y, int colour){
	if((i < 0 || i >= M)) return -1;
	if((j < 0 || j >= N)) return -1;
	
}
void display(const unsigned char *, int M, int N){
	unsigned char disp[M][N];
}
