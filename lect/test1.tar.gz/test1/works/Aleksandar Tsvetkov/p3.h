int getpix(const unsigned char *, int M, int N, int X, int Y);
int setpix(unsigned char *, int M, int N, int X, int Y, int colour);
void display(const unsigned char *, int M, int N);
