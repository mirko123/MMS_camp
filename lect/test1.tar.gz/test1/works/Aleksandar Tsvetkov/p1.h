void clear(unsigned int *, int N);
int get(const unsigned int *, int N, int bit);
int set(unsigned int *, int N, int bit, int boolean);
